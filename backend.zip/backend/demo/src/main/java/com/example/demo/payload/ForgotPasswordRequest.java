package com.example.demo.payload;

import lombok.Data;

@Data
public class ForgotPasswordRequest {
	private String email;

}
