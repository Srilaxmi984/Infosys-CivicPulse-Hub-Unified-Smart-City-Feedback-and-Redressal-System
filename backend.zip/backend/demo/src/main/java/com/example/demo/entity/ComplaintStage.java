package com.example.demo.entity;

public enum ComplaintStage {
    REGISTERED,
    ASSIGNED,
    INSPECTION,
    WORK_IN_PROGRESS,
    COMPLETED
}
