package com.example.demo.entity;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
