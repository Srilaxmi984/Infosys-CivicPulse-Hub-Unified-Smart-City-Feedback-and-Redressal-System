package com.example.demo.entity;

public enum ComplaintCategory {
    WATER,
    ROADS,
    ELECTRICITY,
    SANITATION,
    TRAFFIC,
    OTHER
}
