package com.example.demo.payload;

import lombok.Data;

@Data
public class ComplaintAssignRequestDto {
    private Long officerId;
}
