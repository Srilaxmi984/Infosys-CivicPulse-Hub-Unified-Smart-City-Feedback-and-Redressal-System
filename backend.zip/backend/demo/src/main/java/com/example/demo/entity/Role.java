package com.example.demo.entity;

public enum Role {
    CITIZEN,
    OFFICER,
    ADMIN
}
