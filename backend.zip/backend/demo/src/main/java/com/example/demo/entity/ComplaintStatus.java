package com.example.demo.entity;

public enum ComplaintStatus {
    PENDING,
    IN_PROGRESS,
    RESOLVED,
    REJECTED, REOPENED
}
