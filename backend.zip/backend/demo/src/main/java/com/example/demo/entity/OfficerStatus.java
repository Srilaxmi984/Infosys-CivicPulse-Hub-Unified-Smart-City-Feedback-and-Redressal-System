package com.example.demo.entity;

public enum OfficerStatus {
    AVAILABLE,
    BUSY,
    OVERLOADED
}
